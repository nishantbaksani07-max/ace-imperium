# Vitality MCP

A **read-only** Model Context Protocol server that lets Claude (Claude Code in
VSCode, or Claude Desktop) read your Vitality data and reason over it — "should I
train hard today?", "when should I go to bed?", "which subscriptions should I
review?" — plus a **daily-briefing nudge engine** a scheduled agent can deliver
each morning/evening.

It is intentionally **read-only**: there are no write/mutate tools. Claude can
see your data; it cannot change it. (See [DESIGN](../docs/MCP-INTEGRATION.md) for
the hosted/multi-user path and the write-tool roadmap.)

```
Claude (VSCode / Desktop)  ──stdio──▶  vitality-mcp  ──RLS──▶  Supabase (your data)
                                            │
                                            └─ nudge engine → daily briefing
```

## What it can see (and what it can't)

Server-readable today (lives in Supabase):

| Tool | Data |
|------|------|
| `vitality_whoami` | profile, goal, focus areas, plan tier |
| `vitality_daily_briefing` | **the headline** — prioritized nudges across all domains |
| `vitality_sleep_status` | Whoop/Oura/Fitbit sleep + recovery → recommended bedtime |
| `vitality_training_readiness` | recovery tier (Peak/Solid/Tired/Low/Drained) + weekly volume |
| `vitality_nutrition_today` | calories + protein vs target (Fuel) |
| `vitality_weight_trend` | weigh-ins + trend |
| `vitality_subscriptions` | recurring cost, trials ending, price hikes, renewals |
| `vitality_finance_overview` | net worth, accounts, upcoming orders |
| `vitality_recent_workouts` | logged sessions |
| `vitality_notes` | mentor notes / reminders |
| `vitality_user_facts` | the durable mentor-memory layer |
| `vitality_peak_today` | today's Peak schedule + active vitals goal |

**Not visible** (browser-only `localStorage` today, so the server genuinely can't
reach them): **water**, **daily goals/streaks**, **supplement intake**, **brand
metrics**. The briefing says so rather than pretending. Moving any of these to
Supabase instantly makes them readable — see the design doc.

> **"Cancel a sub I don't use":** Vitality stores no *usage* signal, so the MCP
> can't auto-detect an unused subscription. It surfaces the actionable proxies
> instead — trials ending, price hikes, renewals, and your priciest subs to
> review — and is explicit that you make the keep/cancel call.

## Setup

```bash
cd mcp
npm install
cp .env.example .env      # then fill it in (see below)
npm run build             # compile to dist/
npm run briefing          # smoke test: prints today's briefing
```

### Auth (`.env`)

Two modes — the server picks **user** mode unless you explicitly set the
service-role pair.

- **User mode (recommended, RLS-respecting).** `VITALITY_USER_EMAIL` +
  `VITALITY_USER_PASSWORD`. The server signs in as you with the public anon key;
  every query runs under your own row-level security, exactly like the website.
  Structurally it can only ever see your data.
- **Service-role mode (opt-in, local only).**
  `VITALITY_SUPABASE_SERVICE_ROLE_KEY` + `VITALITY_USER_ID`. This key **bypasses
  RLS** — we scope every query to your user id by hand, but the key could read
  anyone, so it must never reach a client or shared host. (CLAUDE.md hard rule
  #3 — flagged for Luke.) Leave blank unless you have a reason.

## Connect to Claude

Build first (`npm run build`), then add the server from `.mcp.json.example` to
your Claude Code `.mcp.json` (project root) or Claude Desktop config. Restart the
client; the `vitality_*` tools appear. Ask: *"Run my Vitality daily briefing."*

For the morning/evening scheduled report, see [`agents/daily-briefing.md`](agents/daily-briefing.md).

## Dev

```bash
npm run dev         # run from source via tsx (no build)
npm run typecheck   # tsc --noEmit
npm run briefing -- --json   # machine-readable briefing
```

## Layout

```
src/
  env.ts        env loading + auth-mode resolution (tiny built-in .env parser)
  supabase.ts   authenticated client (user session | service role), cached
  util.ts       local date keys, decimal-hour formatting, coercions
  queries.ts    read layer — one function per domain, mirrors lib/coach/collectors
  nudges.ts     the nudge engine + briefing renderer
  index.ts      MCP server — registers the 12 read tools
  cli.ts        one-shot briefing printer (for cron / testing)
agents/
  daily-briefing.md   prompt + wiring for the scheduled report agent
```
