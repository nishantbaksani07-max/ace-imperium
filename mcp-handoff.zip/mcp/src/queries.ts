// Read-only query layer for the Vitality MCP.
//
// One function per domain. Each takes the authenticated client and returns a
// shaped, typed object (never raw rows). Mirrors the column choices in
// lib/coach/context.ts + collectors.ts so the MCP "reads your file" the same way
// the in-app mentor does. Every query is scoped to the user id (redundant under
// RLS in user mode, required in service mode).

import type { VitalityDb } from './supabase.js';
import { dateKeyDaysAgo, getLocalDateKey, num, str, ageFromBirthday, round } from './util.js';

type Row = Record<string, unknown>;

// ── Profile ──────────────────────────────────────────────────────────────────

export interface Profile {
  firstName: string | null;
  sex: string | null;
  age: number | null;
  heightCm: number | null;
  startingWeightKg: number | null;
  units: string | null;
  goal: string | null;
  focusAreas: string[];
  tier: string | null;
  subscriptionStatus: string | null;
  currentPeriodEnd: string | null;
}

export async function getProfile({ db, userId }: VitalityDb): Promise<Profile> {
  const [up, pr] = await Promise.all([
    db
      .from('user_profile')
      .select('first_name, sex, birthday, height_cm, starting_weight_kg, units, goal, focus_areas')
      .eq('user_id', userId)
      .maybeSingle(),
    db
      .from('profiles')
      .select('tier, subscription_status, current_period_end')
      .eq('id', userId)
      .maybeSingle(),
  ]);
  const p = (up.data ?? {}) as Row;
  const b = (pr.data ?? {}) as Row;
  return {
    firstName: str(p.first_name),
    sex: str(p.sex),
    age: ageFromBirthday(p.birthday),
    heightCm: num(p.height_cm),
    startingWeightKg: num(p.starting_weight_kg),
    units: str(p.units),
    goal: str(p.goal),
    focusAreas: Array.isArray(p.focus_areas) ? (p.focus_areas as string[]) : [],
    tier: str(b.tier),
    subscriptionStatus: str(b.subscription_status),
    currentPeriodEnd: str(b.current_period_end),
  };
}

// ── Sleep / recovery (wearables) ───────────────────────────────────────────────

export interface SleepEntry {
  date: string;
  provider: string | null;
  sleepHours: number | null;
  sleepPerf: number | null;
  recovery: number | null;
  hrv: number | null;
  rhr: number | null;
  strain: number | null;
}

export interface SleepPrefs {
  wakeTime: number; // decimal hour
  sleepNeedHours: number;
  recoveryLevel: string | null;
  peakHour: number | null;
}

export interface SleepData {
  entries: SleepEntry[]; // newest first
  prefs: SleepPrefs;
  hasWearable: boolean;
}

const DEFAULT_PREFS: SleepPrefs = {
  wakeTime: 6.5,
  sleepNeedHours: 8,
  recoveryLevel: null,
  peakHour: null,
};

export async function getSleep(v: VitalityDb, days = 14): Promise<SleepData> {
  const { db, userId } = v;
  const [wd, prefs] = await Promise.all([
    db
      .from('wearable_data')
      .select('date, provider, sleep_hours, sleep_perf, recovery, hrv, rhr, strain')
      .eq('user_id', userId)
      .gte('date', dateKeyDaysAgo(days))
      .order('date', { ascending: false }),
    db
      .from('peak_tracker_prefs')
      .select('wake_time, sleep_need_hours, recovery_level, peak_hour')
      .eq('user_id', userId)
      .maybeSingle(),
  ]);

  const entries: SleepEntry[] = ((wd.data as Row[]) ?? []).map((r) => ({
    date: str(r.date) ?? '',
    provider: str(r.provider),
    sleepHours: num(r.sleep_hours),
    sleepPerf: num(r.sleep_perf),
    recovery: num(r.recovery),
    hrv: num(r.hrv),
    rhr: num(r.rhr),
    strain: num(r.strain),
  }));

  const pr = (prefs.data ?? null) as Row | null;
  const resolvedPrefs: SleepPrefs = pr
    ? {
        wakeTime: num(pr.wake_time) ?? DEFAULT_PREFS.wakeTime,
        sleepNeedHours: num(pr.sleep_need_hours) ?? DEFAULT_PREFS.sleepNeedHours,
        recoveryLevel: str(pr.recovery_level),
        peakHour: num(pr.peak_hour),
      }
    : { ...DEFAULT_PREFS };

  return { entries, prefs: resolvedPrefs, hasWearable: entries.length > 0 };
}

// ── Weight ─────────────────────────────────────────────────────────────────────

export interface WeightData {
  entries: { date: string; kg: number; note: string | null }[]; // newest first
  latestKg: number | null;
  deltaKg: number | null;
  trend: 'up' | 'down' | 'steady' | null;
  windowDays: number;
}

export async function getWeights(v: VitalityDb, days = 30): Promise<WeightData> {
  const { db, userId } = v;
  const { data } = await db
    .from('weights')
    .select('date, weight_kg, note')
    .eq('user_id', userId)
    .gte('date', dateKeyDaysAgo(days))
    .order('date', { ascending: false });

  const entries = ((data as Row[]) ?? [])
    .map((r) => ({ date: str(r.date) ?? '', kg: num(r.weight_kg) ?? 0, note: str(r.note) }))
    .filter((e) => e.date);

  const latestKg = entries.length ? entries[0].kg : null;
  let deltaKg: number | null = null;
  let trend: WeightData['trend'] = null;
  if (entries.length >= 2 && latestKg != null) {
    const oldest = entries[entries.length - 1].kg;
    deltaKg = round(latestKg - oldest, 1);
    trend = deltaKg > 0.3 ? 'up' : deltaKg < -0.3 ? 'down' : 'steady';
  }
  return { entries, latestKg, deltaKg, trend, windowDays: days };
}

// ── Nutrition / fuel ────────────────────────────────────────────────────────────

export interface NutritionData {
  onboarded: boolean;
  kcalTarget: number;
  proteinTarget: number;
  carbsTarget: number | null;
  fatTarget: number | null;
  goalOutcome: string | null;
  adaptiveEnabled: boolean;
  today: { kcal: number; protein: number; carbs: number; fat: number; mealCount: number; names: string[] };
  recentAvgKcal: number | null;
  recentLoggedDays: number;
}

export async function getNutrition(v: VitalityDb, todayKey = getLocalDateKey()): Promise<NutritionData> {
  const { db, userId } = v;
  const [goalsRes, mealsRes] = await Promise.all([
    db.from('nutrition_goals').select('*').eq('user_id', userId).maybeSingle(),
    db
      .from('nutrition_meals')
      .select('day_key, totals, what_i_see')
      .eq('user_id', userId)
      .gte('day_key', dateKeyDaysAgo(10))
      .order('logged_at', { ascending: true }),
  ]);

  const g = (goalsRes.data ?? {}) as Row;
  const meals = ((mealsRes.data as Row[]) ?? []).map((r) => {
    const t = (r.totals && typeof r.totals === 'object' ? r.totals : {}) as Row;
    return {
      dayKey: str(r.day_key) ?? '',
      kcal: num(t.kcal) ?? 0,
      protein: num(t.protein) ?? 0,
      carbs: num(t.carbs) ?? 0,
      fat: num(t.fat) ?? 0,
      name: str(r.what_i_see),
    };
  });

  const todayMeals = meals.filter((m) => m.dayKey === todayKey);
  const today = todayMeals.reduce(
    (acc, m) => ({
      kcal: acc.kcal + m.kcal,
      protein: acc.protein + m.protein,
      carbs: acc.carbs + m.carbs,
      fat: acc.fat + m.fat,
      mealCount: acc.mealCount + 1,
      names: m.name ? [...acc.names, m.name] : acc.names,
    }),
    { kcal: 0, protein: 0, carbs: 0, fat: 0, mealCount: 0, names: [] as string[] },
  );

  const byDay = new Map<string, number>();
  for (const m of meals) {
    if (m.dayKey === todayKey) continue;
    byDay.set(m.dayKey, (byDay.get(m.dayKey) ?? 0) + m.kcal);
  }
  const recentAvgKcal = byDay.size
    ? Math.round(Array.from(byDay.values()).reduce((a, b) => a + b, 0) / byDay.size)
    : null;

  return {
    onboarded: Boolean(g.onboarded),
    kcalTarget: num(g.kcal_target) ?? 2400,
    proteinTarget: num(g.protein_target) ?? 180,
    carbsTarget: num(g.carbs_target),
    fatTarget: num(g.fat_target),
    goalOutcome: str(g.goal_outcome),
    adaptiveEnabled: g.adaptive_enabled !== false,
    today: {
      kcal: Math.round(today.kcal),
      protein: Math.round(today.protein),
      carbs: Math.round(today.carbs),
      fat: Math.round(today.fat),
      mealCount: today.mealCount,
      names: today.names.slice(0, 8),
    },
    recentAvgKcal,
    recentLoggedDays: byDay.size,
  };
}

// ── Workouts ─────────────────────────────────────────────────────────────────

export interface WorkoutEntry {
  date: string;
  dayName: string | null;
  submitted: boolean;
  exerciseCount: number;
  setCount: number;
  hasCardio: boolean;
}

export interface WorkoutData {
  entries: WorkoutEntry[]; // newest first
  submittedLast7: number;
  windowDays: number;
}

export async function getWorkouts(v: VitalityDb, days = 14): Promise<WorkoutData> {
  const { db, userId } = v;
  const { data } = await db
    .from('workouts')
    .select('date, day_name, exercises, cardio, submitted_at')
    .eq('user_id', userId)
    .gte('date', dateKeyDaysAgo(days))
    .order('date', { ascending: false });

  const entries: WorkoutEntry[] = ((data as Row[]) ?? []).map((r) => {
    const exercises = Array.isArray(r.exercises) ? (r.exercises as Row[]) : [];
    const setCount = exercises.reduce(
      (acc, ex) => acc + (Array.isArray(ex.sets) ? (ex.sets as unknown[]).length : 0),
      0,
    );
    const cardio = Array.isArray(r.cardio) ? (r.cardio as unknown[]) : [];
    return {
      date: str(r.date) ?? '',
      dayName: str(r.day_name),
      submitted: Boolean(r.submitted_at),
      exerciseCount: exercises.length,
      setCount,
      hasCardio: cardio.length > 0,
    };
  });

  const cutoff7 = dateKeyDaysAgo(7);
  const submittedLast7 = new Set(
    entries.filter((e) => e.submitted && e.date >= cutoff7).map((e) => e.date),
  ).size;

  return { entries, submittedLast7, windowDays: days };
}

// ── Subscriptions ──────────────────────────────────────────────────────────────

export interface Subscription {
  name: string;
  amountChf: number;
  period: string;
  monthlyChf: number;
  renewal: string | null;
  trialEnds: string | null;
  previousAmountChf: number | null;
  priceChangedAt: string | null;
  enteredAmount: number | null;
  enteredCurrency: string | null;
}

export interface SubscriptionData {
  currency: string;
  subs: Subscription[];
  totalMonthlyChf: number;
  totalYearlyChf: number;
}

function toMonthlyChf(amountChf: number, period: string): number {
  switch (period) {
    case 'weekly':
      return (amountChf * 52) / 12;
    case 'yearly':
      return amountChf / 12;
    case 'monthly':
    default:
      return amountChf;
  }
}

export async function getSubscriptions(v: VitalityDb): Promise<SubscriptionData> {
  const { db, userId } = v;
  const [subsRes, prefsRes] = await Promise.all([
    db
      .from('finance_subscriptions')
      .select(
        'name, amount_chf, period, renewal, trial_ends, previous_amount_chf, price_changed_at, entered_amount, entered_currency',
      )
      .eq('user_id', userId),
    db.from('finance_prefs').select('currency').eq('user_id', userId).maybeSingle(),
  ]);

  const subs: Subscription[] = ((subsRes.data as Row[]) ?? []).map((r) => {
    const amountChf = num(r.amount_chf) ?? 0;
    const period = str(r.period) ?? 'monthly';
    return {
      name: str(r.name) ?? 'Unnamed',
      amountChf,
      period,
      monthlyChf: round(toMonthlyChf(amountChf, period), 2),
      renewal: str(r.renewal),
      trialEnds: str(r.trial_ends),
      previousAmountChf: num(r.previous_amount_chf),
      priceChangedAt: str(r.price_changed_at),
      enteredAmount: num(r.entered_amount),
      enteredCurrency: str(r.entered_currency),
    };
  });

  const totalMonthlyChf = round(
    subs.reduce((acc, s) => acc + s.monthlyChf, 0),
    2,
  );
  return {
    currency: (prefsRes.data as Row | null)?.currency as string | undefined ?? 'CHF',
    subs: subs.sort((a, b) => b.monthlyChf - a.monthlyChf),
    totalMonthlyChf,
    totalYearlyChf: round(totalMonthlyChf * 12, 2),
  };
}

// ── Finance overview ────────────────────────────────────────────────────────────

export interface FinanceOverview {
  currency: string;
  netWorthChf: number;
  accounts: { type: string | null; name: string | null; amountChf: number; ticker: string | null; shares: number | null }[];
  upcomingOrders: { name: string | null; amountChf: number; arrivalDate: string | null; direction: string }[];
}

export async function getFinanceOverview(v: VitalityDb): Promise<FinanceOverview> {
  const { db, userId } = v;
  const [accRes, ordRes, prefsRes] = await Promise.all([
    db
      .from('finance_accounts')
      .select('type, name, amount_chf, ticker, shares')
      .eq('user_id', userId),
    db
      .from('finance_orders')
      .select('name, amount_chf, arrival_date, direction, deducted_at')
      .eq('user_id', userId)
      .is('deducted_at', null),
    db.from('finance_prefs').select('currency').eq('user_id', userId).maybeSingle(),
  ]);

  const accounts = ((accRes.data as Row[]) ?? []).map((r) => ({
    type: str(r.type),
    name: str(r.name),
    amountChf: num(r.amount_chf) ?? 0,
    ticker: str(r.ticker),
    shares: num(r.shares),
  }));
  const netWorthChf = round(
    accounts.reduce((acc, a) => acc + a.amountChf, 0),
    2,
  );
  const upcomingOrders = ((ordRes.data as Row[]) ?? []).map((r) => ({
    name: str(r.name),
    amountChf: num(r.amount_chf) ?? 0,
    arrivalDate: str(r.arrival_date),
    direction: str(r.direction) ?? 'out',
  }));

  return {
    currency: ((prefsRes.data as Row | null)?.currency as string | undefined) ?? 'CHF',
    netWorthChf,
    accounts,
    upcomingOrders,
  };
}

// ── Notes / reminders ─────────────────────────────────────────────────────────

export async function getNotes(v: VitalityDb, days = 10, limit = 25): Promise<{ body: string; createdAt: string }[]> {
  const { db, userId } = v;
  const { data } = await db
    .from('notes')
    .select('body, created_at')
    .eq('user_id', userId)
    .gte('created_at', `${dateKeyDaysAgo(days)}T00:00:00Z`)
    .order('created_at', { ascending: false })
    .limit(limit);
  return ((data as Row[]) ?? [])
    .map((r) => ({ body: str(r.body) ?? '', createdAt: str(r.created_at) ?? '' }))
    .filter((n) => n.body);
}

// ── Durable user facts (shared mentor memory) ──────────────────────────────────

export async function getUserFacts(
  v: VitalityDb,
  limit = 25,
): Promise<{ kind: string | null; body: string; salience: number | null; source: string | null }[]> {
  const { db, userId } = v;
  const { data } = await db
    .from('user_facts')
    .select('kind, body, salience, source, expires_at')
    .eq('user_id', userId)
    .order('salience', { ascending: false })
    .limit(limit);
  const nowIso = new Date().toISOString();
  return ((data as Row[]) ?? [])
    .filter((r) => {
      const exp = str(r.expires_at);
      return !exp || exp > nowIso;
    })
    .map((r) => ({
      kind: str(r.kind),
      body: str(r.body) ?? '',
      salience: num(r.salience),
      source: str(r.source),
    }))
    .filter((f) => f.body);
}

// ── Peak schedule (today) ──────────────────────────────────────────────────────

export interface PeakTask {
  hour: number | null;
  endHour: number | null;
  title: string;
  done: boolean;
  kind: string;
  eventType: string | null;
}

export async function getPeakToday(v: VitalityDb, todayKey = getLocalDateKey()): Promise<PeakTask[]> {
  const { db, userId } = v;
  const { data } = await db
    .from('peak_tracker_tasks')
    .select('hour, end_hour, title, done, kind, event_type, position')
    .eq('user_id', userId)
    .eq('date', todayKey)
    .order('hour', { ascending: true })
    .order('position', { ascending: true });
  return ((data as Row[]) ?? []).map((r) => ({
    hour: num(r.hour),
    endHour: num(r.end_hour),
    title: str(r.title) ?? '',
    done: Boolean(r.done),
    kind: str(r.kind) ?? 'task',
    eventType: str(r.event_type),
  }));
}

// ── Active vitals goal ──────────────────────────────────────────────────────────

export async function getVitalsGoal(
  v: VitalityDb,
): Promise<{ metric: string; direction: string; targetValue: number | null; confidence: string | null; status: string } | null> {
  const { db, userId } = v;
  const { data } = await db
    .from('vitals_goals')
    .select('metric, direction, target_value, confidence, status')
    .eq('user_id', userId)
    .eq('status', 'active')
    .maybeSingle();
  const r = data as Row | null;
  if (!r) return null;
  return {
    metric: str(r.metric) ?? '',
    direction: str(r.direction) ?? '',
    targetValue: num(r.target_value),
    confidence: str(r.confidence),
    status: str(r.status) ?? 'active',
  };
}
