// Nudge engine for the Vitality MCP.
//
// Pulls the read layer, then derives a prioritized list of nudges across every
// server-readable domain. This is what powers `vitality_daily_briefing` and the
// scheduled morning/evening agent. Pure derivation — no writes, no side effects.
//
// Honesty rule: anything the server genuinely cannot see (water, goals, brand,
// supplements — all browser-only localStorage today) is reported as a known gap,
// never silently dropped.

import type { VitalityDb } from './supabase.js';
import { fmtHour, getLocalDateKey, round } from './util.js';
import {
  getProfile,
  getSleep,
  getWeights,
  getNutrition,
  getWorkouts,
  getSubscriptions,
  getNotes,
  type SleepData,
  type WeightData,
  type NutritionData,
  type WorkoutData,
  type SubscriptionData,
  type Profile,
} from './queries.js';

export type Severity = 'urgent' | 'suggest' | 'info';

export interface Nudge {
  domain: 'sleep' | 'training' | 'nutrition' | 'weight' | 'finance' | 'reminders' | 'coverage';
  severity: Severity;
  title: string;
  detail: string;
}

const SEVERITY_RANK: Record<Severity, number> = { urgent: 0, suggest: 1, info: 2 };

// ── Recovery → training tier (SKILL.md "Vitality score" tiers) ─────────────────
function recoveryTier(recovery: number): { label: string; advice: string } {
  if (recovery >= 80) return { label: 'Peak', advice: 'push hard — green light for a heavy session' };
  if (recovery >= 65) return { label: 'Solid', advice: 'train normal' };
  if (recovery >= 50) return { label: 'Tired', advice: 'keep it moderate, trim the top sets' };
  if (recovery >= 35) return { label: 'Low', advice: 'go light or take active recovery' };
  return { label: 'Drained', advice: 'rest today — your body is asking for it' };
}

// ── Sleep ──────────────────────────────────────────────────────────────────────
function sleepNudges(sleep: SleepData): Nudge[] {
  const out: Nudge[] = [];
  const { wakeTime, sleepNeedHours } = sleep.prefs;
  const baselineBedtime = wakeTime - sleepNeedHours;

  if (!sleep.hasWearable) {
    out.push({
      domain: 'sleep',
      severity: 'info',
      title: `Target lights-out around ${fmtHour(baselineBedtime)}`,
      detail: `To wake at ${fmtHour(wakeTime)} with ${sleepNeedHours}h of sleep. No wearable is connected, so this is from your Peak schedule prefs only — connect Whoop, Oura, or Fitbit for recovery-aware timing.`,
    });
    return out;
  }

  // Sleep debt over the entries we have (cap at last 7).
  const recent = sleep.entries.filter((e) => e.sleepHours != null).slice(0, 7);
  let debt = 0;
  for (const e of recent) debt += Math.max(0, sleepNeedHours - (e.sleepHours ?? sleepNeedHours));
  debt = round(debt, 1);

  const latest = sleep.entries[0];
  const latestRecovery = sleep.entries.find((e) => e.recovery != null)?.recovery ?? null;

  // Earlier-bedtime shift if carrying meaningful debt or low recovery.
  let shift = 0;
  if (debt >= 3) shift = Math.min(1, debt / 6);
  if (latestRecovery != null && latestRecovery < 50) shift = Math.max(shift, 0.5);
  const targetBedtime = baselineBedtime - shift;

  out.push({
    domain: 'sleep',
    severity: shift > 0 ? 'suggest' : 'info',
    title: `Lights out around ${fmtHour(targetBedtime)} tonight`,
    detail:
      `Wake target ${fmtHour(wakeTime)}, sleep need ${sleepNeedHours}h.` +
      (debt >= 1 ? ` You're carrying ~${debt}h of sleep debt over the last week.` : '') +
      (shift > 0 ? ` Shifting bedtime ${Math.round(shift * 60)} min earlier to claw it back.` : ' You\'re on track — hold the routine.'),
  });

  if (latestRecovery != null && latestRecovery < 50) {
    out.push({
      domain: 'sleep',
      severity: 'suggest',
      title: `Recovery is ${latestRecovery} — prioritize an early night`,
      detail: `Latest reading${latest?.date ? ` (${latest.date})` : ''} is in the low band. Sleep is the highest-leverage lever here: protect the wind-down, kill the late screens.`,
    });
  }

  return out;
}

// ── Training readiness ──────────────────────────────────────────────────────────
function trainingNudges(sleep: SleepData, workouts: WorkoutData): Nudge[] {
  const out: Nudge[] = [];
  const latestRecovery = sleep.entries.find((e) => e.recovery != null)?.recovery ?? null;

  if (latestRecovery != null) {
    const tier = recoveryTier(latestRecovery);
    out.push({
      domain: 'training',
      severity: latestRecovery < 35 ? 'suggest' : 'info',
      title: `Recovery ${latestRecovery} (${tier.label}) — ${tier.advice}`,
      detail: `Training read for today is "${tier.label}". ${tier.advice[0].toUpperCase()}${tier.advice.slice(1)}.`,
    });
  }

  if (workouts.submittedLast7 === 0) {
    out.push({
      domain: 'training',
      severity: 'suggest',
      title: 'No sessions logged in the last 7 days',
      detail: 'Either a deliberate deload or the logger slipped — worth a check-in if you meant to train.',
    });
  } else {
    out.push({
      domain: 'training',
      severity: 'info',
      title: `${workouts.submittedLast7} session${workouts.submittedLast7 === 1 ? '' : 's'} logged this week`,
      detail: workouts.entries[0]?.dayName
        ? `Most recent: ${workouts.entries[0].dayName} on ${workouts.entries[0].date}.`
        : 'Keep the streak honest.',
    });
  }

  return out;
}

// ── Subscriptions / finance ──────────────────────────────────────────────────────
function subscriptionNudges(subs: SubscriptionData, todayKey: string): Nudge[] {
  const out: Nudge[] = [];
  if (subs.subs.length === 0) return out;

  out.push({
    domain: 'finance',
    severity: 'info',
    title: `${subs.totalMonthlyChf} CHF/mo in subscriptions (~${subs.totalYearlyChf} CHF/yr)`,
    detail: `${subs.subs.length} active across your stack. Display currency is ${subs.currency}; figures shown in canonical CHF.`,
  });

  const within = (dateStr: string | null, days: number): boolean => {
    if (!dateStr) return false;
    const target = new Date(dateStr + 'T00:00:00');
    const now = new Date(todayKey + 'T00:00:00');
    const diff = (target.getTime() - now.getTime()) / 86_400_000;
    return diff >= 0 && diff <= days;
  };

  // Trial ending — the most actionable, time-boxed nudge.
  for (const s of subs.subs) {
    if (within(s.trialEnds, 7)) {
      out.push({
        domain: 'finance',
        severity: 'urgent',
        title: `${s.name}: free trial ends ${s.trialEnds}`,
        detail: `Decide before it converts to ${s.amountChf} CHF/${s.period}. Cancel now if you're not keeping it.`,
      });
    }
  }

  // Price hikes.
  for (const s of subs.subs) {
    if (s.previousAmountChf != null && s.amountChf > s.previousAmountChf) {
      const up = round(s.amountChf - s.previousAmountChf, 2);
      out.push({
        domain: 'finance',
        severity: 'suggest',
        title: `${s.name} got more expensive (+${up} CHF)`,
        detail: `Now ${s.amountChf} CHF/${s.period}, was ${s.previousAmountChf}${s.priceChangedAt ? ` (changed ${s.priceChangedAt})` : ''}. Still worth it?`,
      });
    }
  }

  // Upcoming renewals (informational heads-up).
  const renewingSoon = subs.subs.filter((s) => within(s.renewal, 7));
  if (renewingSoon.length) {
    out.push({
      domain: 'finance',
      severity: 'info',
      title: `${renewingSoon.length} subscription${renewingSoon.length === 1 ? '' : 's'} renew this week`,
      detail: renewingSoon.map((s) => `${s.name} (${s.renewal}, ${s.amountChf} CHF)`).join(' · '),
    });
  }

  // Review candidates — the honest version of "cancel what you don't use".
  // Vitality stores no usage signal, so we surface the priciest and say so.
  const candidates = subs.subs.slice(0, 3);
  if (candidates.length) {
    out.push({
      domain: 'finance',
      severity: 'suggest',
      title: 'Worth a review: your priciest subscriptions',
      detail:
        candidates.map((s) => `${s.name} (${round(s.monthlyChf, 2)} CHF/mo)`).join(' · ') +
        '. Heads up: Vitality does not track last-used, so I can\'t tell which you actually use — these are simply the costliest. You decide if each earns its keep.',
    });
  }

  return out;
}

// ── Nutrition ────────────────────────────────────────────────────────────────────
function nutritionNudges(n: NutritionData): Nudge[] {
  if (!n.onboarded) return [];
  const out: Nudge[] = [];
  const { today, kcalTarget, proteinTarget } = n;

  const kcalLeft = kcalTarget - today.kcal;
  out.push({
    domain: 'nutrition',
    severity: 'info',
    title: `${today.kcal}/${kcalTarget} kcal · ${today.protein}/${proteinTarget}g protein today`,
    detail:
      today.mealCount === 0
        ? 'Nothing logged yet today.'
        : `${today.mealCount} meal${today.mealCount === 1 ? '' : 's'} logged. ${kcalLeft >= 0 ? `${Math.round(kcalLeft)} kcal left` : `${Math.round(-kcalLeft)} kcal over`}.`,
  });

  const proteinGap = proteinTarget - today.protein;
  if (today.mealCount > 0 && proteinGap > proteinTarget * 0.4) {
    out.push({
      domain: 'nutrition',
      severity: 'suggest',
      title: `Protein is short by ~${Math.round(proteinGap)}g`,
      detail: `At ${today.protein}/${proteinTarget}g. A protein-forward next meal closes the gap.`,
    });
  }

  return out;
}

// ── Weight ───────────────────────────────────────────────────────────────────────
function weightNudges(w: WeightData, profile: Profile, nutrition: NutritionData): Nudge[] {
  if (w.latestKg == null) return [];
  const out: Nudge[] = [];
  const isImperial = profile.units === 'imperial';
  const show = (kg: number) => (isImperial ? `${round(kg * 2.20462, 1)} lb` : `${round(kg, 1)} kg`);

  out.push({
    domain: 'weight',
    severity: 'info',
    title: `Weight ${show(w.latestKg)}${w.deltaKg != null ? ` (${w.deltaKg >= 0 ? '+' : ''}${show(w.deltaKg)} over ${w.windowDays}d)` : ''}`,
    detail: w.trend ? `Trend: ${w.trend}.` : 'Not enough entries to trend yet.',
  });

  const goal = nutrition.goalOutcome ?? profile.goal;
  if (goal && w.trend) {
    const misaligned =
      ((goal === 'cut' || goal === 'fat_loss') && w.trend === 'up') ||
      ((goal === 'bulk' || goal === 'muscle') && w.trend === 'down');
    if (misaligned) {
      out.push({
        domain: 'weight',
        severity: 'suggest',
        title: `Trend is fighting your "${goal}" goal`,
        detail: `Weight is trending ${w.trend} while you're aiming to ${goal}. Worth revisiting calories — the adaptive engine in Fuel can recalibrate.`,
      });
    }
  }

  return out;
}

// ── Reminders (notes) ────────────────────────────────────────────────────────────
function reminderNudges(notes: { body: string; createdAt: string }[]): Nudge[] {
  if (!notes.length) return [];
  // Surface the most recent few — these often carry time-sensitive intent.
  return notes.slice(0, 4).map((note) => ({
    domain: 'reminders' as const,
    severity: 'info' as const,
    title: 'From your notes',
    detail: note.body,
  }));
}

// ── Coverage gap (honesty footer) ─────────────────────────────────────────────────
function coverageNudge(): Nudge {
  return {
    domain: 'coverage',
    severity: 'info',
    title: 'Not visible to this briefing',
    detail:
      'Water, daily goals/streaks, supplement intake, and brand metrics live only in your browser today (localStorage), so the server can\'t see them. Sleep, training, nutrition, weight, subscriptions, finances, and notes are all live above.',
  };
}

export interface Briefing {
  generatedAt: string;
  dayKey: string;
  greetingName: string | null;
  nudges: Nudge[];
}

/** Build the full daily briefing across every server-readable domain. */
export async function buildBriefing(v: VitalityDb): Promise<Briefing> {
  const todayKey = getLocalDateKey();
  const [profile, sleep, weights, nutrition, workouts, subs, notes] = await Promise.all([
    getProfile(v),
    getSleep(v, 14),
    getWeights(v, 30),
    getNutrition(v, todayKey),
    getWorkouts(v, 14),
    getSubscriptions(v),
    getNotes(v, 5, 10),
  ]);

  const nudges: Nudge[] = [
    ...sleepNudges(sleep),
    ...trainingNudges(sleep, workouts),
    ...nutritionNudges(nutrition),
    ...weightNudges(weights, profile, nutrition),
    ...subscriptionNudges(subs, todayKey),
    ...reminderNudges(notes),
    coverageNudge(),
  ];

  nudges.sort((a, b) => SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity]);

  return {
    generatedAt: new Date().toISOString(),
    dayKey: todayKey,
    greetingName: profile.firstName,
    nudges,
  };
}

/** Render a briefing as readable text for an agent or terminal. */
export function renderBriefing(b: Briefing): string {
  const icon: Record<Severity, string> = { urgent: '🔴', suggest: '🟡', info: '·' };
  const lines: string[] = [];
  lines.push(`Vitality briefing — ${b.dayKey}${b.greetingName ? ` for ${b.greetingName}` : ''}`);
  lines.push('');
  for (const n of b.nudges) {
    lines.push(`${icon[n.severity]} [${n.domain}] ${n.title}`);
    lines.push(`    ${n.detail}`);
  }
  return lines.join('\n');
}
