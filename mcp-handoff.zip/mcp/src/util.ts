// Small shared helpers: local date keys (matching the app's convention),
// decimal-hour formatting, and safe coercions.

import { getEnv } from './env.js';

/** Local YYYY-MM-DD, honoring VITALITY_TIMEZONE if set, else host local time.
 *  Mirrors the app's getLocalDateKey() (never toISOString — UTC drift). */
export function getLocalDateKey(date = new Date()): string {
  const tz = getEnv().timezone;
  if (tz) {
    // en-CA yields YYYY-MM-DD parts.
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: tz,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(date);
    return parts;
  }
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(
    date.getDate(),
  ).padStart(2, '0')}`;
}

/** A date key N days before today. */
export function dateKeyDaysAgo(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return getLocalDateKey(d);
}

/** Decimal hour (e.g. 22.5) → "10:30 PM". */
export function fmtHour(decimalHour: number): string {
  let h = ((decimalHour % 24) + 24) % 24;
  const hours = Math.floor(h);
  const mins = Math.round((h - hours) * 60);
  // round-up of minutes can push to next hour
  let hh = hours;
  let mm = mins;
  if (mm === 60) {
    mm = 0;
    hh = (hh + 1) % 24;
  }
  const ampm = hh < 12 ? 'AM' : 'PM';
  let display = hh % 12;
  if (display === 0) display = 12;
  return `${display}:${String(mm).padStart(2, '0')} ${ampm}`;
}

export const num = (v: unknown): number | null => {
  const x = Number(v);
  return Number.isFinite(x) ? x : null;
};

export const str = (v: unknown): string | null =>
  typeof v === 'string' && v.trim() ? v.trim() : null;

export function ageFromBirthday(birthday: unknown): number | null {
  const b = str(birthday);
  if (!b) return null;
  const [y, m, d] = b.split('-').map(Number);
  if (!y || !m || !d) return null;
  const today = new Date();
  let age = today.getFullYear() - y;
  const md = today.getMonth() + 1 - m;
  if (md < 0 || (md === 0 && today.getDate() < d)) age -= 1;
  return age > 0 && age < 130 ? age : null;
}

/** Round to at most `places` decimals, dropping trailing zeros. */
export function round(n: number, places = 1): number {
  const f = Math.pow(10, places);
  return Math.round(n * f) / f;
}
