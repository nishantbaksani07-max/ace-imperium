#!/usr/bin/env node
// Vitality MCP — read-only stdio server.
//
// Exposes a single Vitality user's data (sleep, training, nutrition, weight,
// finances, notes, durable facts) to an MCP client (Claude Code / Desktop), plus
// a `vitality_daily_briefing` tool that runs the nudge engine. Read-only: there
// are no write/mutate tools by design.
//
// stdout is the protocol channel — all human logging goes to stderr.

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';

import { getDb } from './supabase.js';
import { fmtHour, getLocalDateKey, round } from './util.js';
import {
  getProfile,
  getSleep,
  getWeights,
  getNutrition,
  getWorkouts,
  getSubscriptions,
  getFinanceOverview,
  getNotes,
  getUserFacts,
  getPeakToday,
  getVitalsGoal,
} from './queries.js';
import { buildBriefing, renderBriefing } from './nudges.js';

type ToolResult = { content: { type: 'text'; text: string }[]; isError?: boolean };

const text = (t: string): ToolResult => ({ content: [{ type: 'text', text: t }] });

/** Wrap a handler so auth/query failures return a clean tool error, not a crash. */
function safe(fn: () => Promise<string>) {
  return async (): Promise<ToolResult> => {
    try {
      return text(await fn());
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      console.error('[vitality-mcp] tool error:', msg);
      return { content: [{ type: 'text', text: `Vitality error: ${msg}` }], isError: true };
    }
  };
}

const server = new McpServer({ name: 'vitality', version: '0.1.0' });

// ── whoami ──────────────────────────────────────────────────────────────────
server.registerTool(
  'vitality_whoami',
  {
    title: 'Who am I',
    description:
      'Profile + plan summary for the connected Vitality user: name, age, sex, units, goal, focus areas, and billing tier/subscription status. Call this first to ground every other answer.',
  },
  safe(async () => {
    const v = await getDb();
    const p = await getProfile(v);
    const lines = [
      `Name: ${p.firstName ?? '(unset)'}`,
      `Sex/age: ${p.sex ?? '?'} / ${p.age ?? '?'}`,
      `Units: ${p.units ?? 'metric'}`,
      p.heightCm ? `Height: ${p.heightCm} cm` : null,
      p.startingWeightKg ? `Starting weight: ${p.startingWeightKg} kg` : null,
      `Goal: ${p.goal ?? '(none set)'}`,
      p.focusAreas.length ? `Focus areas: ${p.focusAreas.join(', ')}` : null,
      `Plan tier: ${p.tier ?? 'free'}${p.subscriptionStatus ? ` (${p.subscriptionStatus})` : ''}`,
      p.currentPeriodEnd ? `Current period ends: ${p.currentPeriodEnd}` : null,
      `Connection: ${v.mode === 'service' ? 'service-role (RLS bypassed — local only)' : 'user session (RLS-scoped)'}`,
    ].filter(Boolean);
    return lines.join('\n');
  }),
);

// ── daily briefing (the nudge engine) ─────────────────────────────────────────
server.registerTool(
  'vitality_daily_briefing',
  {
    title: 'Daily briefing',
    description:
      'The headline tool. Runs the nudge engine across every server-readable domain (sleep/recovery, training readiness, nutrition, weight, subscriptions, reminders) and returns a prioritized briefing: 🔴 urgent, 🟡 suggested, · info. This is what a scheduled morning/evening agent should call. Also states what it cannot see (browser-only modules).',
  },
  safe(async () => {
    const v = await getDb();
    const b = await buildBriefing(v);
    return renderBriefing(b);
  }),
);

// ── sleep status ──────────────────────────────────────────────────────────────
server.registerTool(
  'vitality_sleep_status',
  {
    title: 'Sleep & recovery status',
    description:
      'Recent wearable sleep/recovery (Whoop/Oura/Fitbit) plus the computed recommended bedtime to hit the user\'s wake time and sleep need. Answers "when should I sleep?". days defaults to 14.',
    inputSchema: { days: z.number().int().min(1).max(60).optional().describe('How many days of history to read (default 14)') },
  },
  async ({ days }: { days?: number }): Promise<ToolResult> => {
    return safe(async () => {
      const v = await getDb();
      const s = await getSleep(v, days ?? 14);
      const bedtime = s.prefs.wakeTime - s.prefs.sleepNeedHours;
      const lines: string[] = [
        `Recommended lights-out: ~${fmtHour(bedtime)} (wake ${fmtHour(s.prefs.wakeTime)}, need ${s.prefs.sleepNeedHours}h).`,
      ];
      if (!s.hasWearable) {
        lines.push('No wearable connected — connect Whoop/Oura/Fitbit for recovery-aware timing.');
        return lines.join('\n');
      }
      const recent = s.entries.slice(0, 7);
      const sleptVals = recent.map((e) => e.sleepHours).filter((x): x is number => x != null);
      if (sleptVals.length) {
        const avg = round(sleptVals.reduce((a, b) => a + b, 0) / sleptVals.length, 1);
        const debt = round(
          recent.reduce((acc, e) => acc + Math.max(0, s.prefs.sleepNeedHours - (e.sleepHours ?? s.prefs.sleepNeedHours)), 0),
          1,
        );
        lines.push(`Last ${sleptVals.length} nights: avg ${avg}h, sleep debt ~${debt}h vs need.`);
      }
      lines.push('');
      lines.push('Recent readings (newest first):');
      for (const e of recent) {
        lines.push(
          `  ${e.date} [${e.provider ?? '?'}] ` +
            [
              e.sleepHours != null ? `sleep ${round(e.sleepHours, 1)}h` : null,
              e.sleepPerf != null ? `perf ${e.sleepPerf}%` : null,
              e.recovery != null ? `recovery ${e.recovery}` : null,
              e.hrv != null ? `hrv ${e.hrv}` : null,
              e.rhr != null ? `rhr ${e.rhr}` : null,
              e.strain != null ? `strain ${e.strain}` : null,
            ]
              .filter(Boolean)
              .join(' · '),
        );
      }
      return lines.join('\n');
    })();
  },
);

// ── training readiness ─────────────────────────────────────────────────────────
server.registerTool(
  'vitality_training_readiness',
  {
    title: 'Training readiness',
    description:
      'Today\'s train/rest read from latest recovery (Peak/Solid/Tired/Low/Drained tiers) plus how many sessions were logged in the last 7 days. Answers "should I train hard today?".',
  },
  safe(async () => {
    const v = await getDb();
    const [s, w] = await Promise.all([getSleep(v, 7), getWorkouts(v, 14)]);
    const rec = s.entries.find((e) => e.recovery != null)?.recovery ?? null;
    const lines: string[] = [];
    if (rec != null) {
      const tier =
        rec >= 80 ? 'Peak — push hard'
        : rec >= 65 ? 'Solid — train normal'
        : rec >= 50 ? 'Tired — keep it moderate'
        : rec >= 35 ? 'Low — light / active recovery'
        : 'Drained — rest';
      lines.push(`Recovery ${rec} → ${tier}.`);
    } else {
      lines.push('No recovery score available (Fitbit has no recovery metric; Whoop/Oura do). Train by feel.');
    }
    lines.push(`Sessions logged in the last 7 days: ${w.submittedLast7}.`);
    if (w.entries[0]) lines.push(`Most recent: ${w.entries[0].dayName ?? 'session'} on ${w.entries[0].date} (${w.entries[0].setCount} sets).`);
    return lines.join('\n');
  }),
);

// ── nutrition today ──────────────────────────────────────────────────────────
server.registerTool(
  'vitality_nutrition_today',
  {
    title: "Today's nutrition",
    description:
      'Today\'s calories and protein vs target, meal count, and recent daily-average calories. Reads the Fuel module (nutrition_goals + nutrition_meals).',
  },
  safe(async () => {
    const v = await getDb();
    const n = await getNutrition(v);
    if (!n.onboarded) return 'Fuel (nutrition) is not set up yet for this user.';
    const lines = [
      `Targets: ${n.kcalTarget} kcal, ${n.proteinTarget}g protein${n.goalOutcome ? ` (goal: ${n.goalOutcome})` : ''}.`,
      `Today: ${n.today.kcal} kcal, ${n.today.protein}g protein, ${n.today.carbs}g carbs, ${n.today.fat}g fat across ${n.today.mealCount} meal(s).`,
      n.today.names.length ? `Meals: ${n.today.names.join('; ')}.` : null,
      n.recentAvgKcal != null ? `Recent: avg ${n.recentAvgKcal} kcal over ${n.recentLoggedDays} logged day(s).` : null,
    ].filter(Boolean);
    return lines.join('\n');
  }),
);

// ── weight trend ──────────────────────────────────────────────────────────────
server.registerTool(
  'vitality_weight_trend',
  {
    title: 'Weight trend',
    description: 'Weigh-in history and trend over a window (default 30 days).',
    inputSchema: { days: z.number().int().min(7).max(365).optional().describe('Window in days (default 30)') },
  },
  async ({ days }: { days?: number }): Promise<ToolResult> => {
    return safe(async () => {
      const v = await getDb();
      const w = await getWeights(v, days ?? 30);
      if (!w.entries.length) return 'No weigh-ins recorded in this window.';
      const lines = [
        `Latest: ${w.latestKg} kg.`,
        w.deltaKg != null ? `Change over ${w.windowDays}d: ${w.deltaKg >= 0 ? '+' : ''}${w.deltaKg} kg (${w.trend}).` : 'Need ≥2 entries to trend.',
        '',
        'Entries (newest first):',
        ...w.entries.slice(0, 14).map((e) => `  ${e.date}: ${e.kg} kg${e.note ? ` — ${e.note}` : ''}`),
      ];
      return lines.join('\n');
    })();
  },
);

// ── subscriptions ──────────────────────────────────────────────────────────────
server.registerTool(
  'vitality_subscriptions',
  {
    title: 'Subscriptions',
    description:
      'All recurring subscriptions with monthly-normalized cost, total burn, trials ending soon, recent price hikes, and renewals due this week. Note: Vitality stores no usage signal, so "unused" cannot be auto-detected — this surfaces cost, trials, and price changes instead.',
  },
  safe(async () => {
    const v = await getDb();
    const s = await getSubscriptions(v);
    if (!s.subs.length) return 'No subscriptions recorded (or finance not yet synced to the server).';
    const todayKey = getLocalDateKey();
    const lines = [
      `Total: ${s.totalMonthlyChf} CHF/mo (~${s.totalYearlyChf} CHF/yr) across ${s.subs.length}. Display currency ${s.currency}; figures in CHF.`,
      '',
      ...s.subs.map((sub) => {
        const flags = [
          sub.trialEnds ? `trial ends ${sub.trialEnds}` : null,
          sub.previousAmountChf != null && sub.amountChf > sub.previousAmountChf ? `↑ from ${sub.previousAmountChf}` : null,
          sub.renewal ? `renews ${sub.renewal}` : null,
        ].filter(Boolean);
        return `  ${sub.name}: ${sub.amountChf} CHF/${sub.period} (${sub.monthlyChf} CHF/mo)${flags.length ? ` — ${flags.join(', ')}` : ''}`;
      }),
      '',
      `Today is ${todayKey}. No last-used tracking exists — judge "worth keeping" yourself; the costliest are listed first.`,
    ];
    return lines.join('\n');
  }),
);

// ── finance overview ──────────────────────────────────────────────────────────
server.registerTool(
  'vitality_finance_overview',
  {
    title: 'Finance overview',
    description: 'Net worth, accounts (bank/stocks/crypto/other), and upcoming orders/income not yet deducted. All in canonical CHF.',
  },
  safe(async () => {
    const v = await getDb();
    const f = await getFinanceOverview(v);
    if (!f.accounts.length && !f.upcomingOrders.length) return 'No finance data on the server yet for this user.';
    const lines = [
      `Net worth: ${f.netWorthChf} CHF (display currency ${f.currency}).`,
      '',
      'Accounts:',
      ...f.accounts.map((a) => `  [${a.type ?? '?'}] ${a.name ?? '?'}: ${a.amountChf} CHF${a.ticker ? ` (${a.shares ?? '?'} × ${a.ticker})` : ''}`),
    ];
    if (f.upcomingOrders.length) {
      lines.push('', 'Upcoming (not yet deducted):');
      for (const o of f.upcomingOrders) {
        lines.push(`  ${o.direction === 'in' ? '+' : '-'}${o.amountChf} CHF ${o.name ?? ''}${o.arrivalDate ? ` (≈${o.arrivalDate})` : ''}`);
      }
    }
    return lines.join('\n');
  }),
);

// ── recent workouts ─────────────────────────────────────────────────────────────
server.registerTool(
  'vitality_recent_workouts',
  {
    title: 'Recent workouts',
    description: 'Logged workout sessions over a window (default 14 days): day name, sets, whether submitted, cardio flag.',
    inputSchema: { days: z.number().int().min(1).max(90).optional().describe('Window in days (default 14)') },
  },
  async ({ days }: { days?: number }): Promise<ToolResult> => {
    return safe(async () => {
      const v = await getDb();
      const w = await getWorkouts(v, days ?? 14);
      if (!w.entries.length) return 'No workouts logged in this window.';
      return [
        `${w.entries.length} session(s); ${w.submittedLast7} submitted in the last 7 days.`,
        '',
        ...w.entries.map(
          (e) => `  ${e.date} — ${e.dayName ?? 'session'}: ${e.exerciseCount} exercises, ${e.setCount} sets${e.hasCardio ? ' + cardio' : ''}${e.submitted ? '' : ' (in progress)'}`,
        ),
      ].join('\n');
    })();
  },
);

// ── notes / reminders ────────────────────────────────────────────────────────
server.registerTool(
  'vitality_notes',
  {
    title: 'Notes & reminders',
    description: 'Recent notes from the Mentor "void"/quick-jot inbox — often carry time-sensitive intent (events, reminders). days defaults to 10.',
    inputSchema: { days: z.number().int().min(1).max(60).optional().describe('Look-back window in days (default 10)') },
  },
  async ({ days }: { days?: number }): Promise<ToolResult> => {
    return safe(async () => {
      const v = await getDb();
      const notes = await getNotes(v, days ?? 10, 25);
      if (!notes.length) return 'No notes in this window.';
      return notes.map((n) => `  • ${n.body}  (${n.createdAt.slice(0, 10)})`).join('\n');
    })();
  },
);

// ── durable user facts ──────────────────────────────────────────────────────────
server.registerTool(
  'vitality_user_facts',
  {
    title: 'Durable user facts',
    description: 'The shared mentor memory layer — durable facts about the user (hobbies, stressors, preferences, context), ranked by salience.',
  },
  safe(async () => {
    const v = await getDb();
    const facts = await getUserFacts(v, 30);
    if (!facts.length) return 'No durable facts recorded yet.';
    return facts.map((f) => `  • (${f.kind ?? 'fact'}, ${f.source ?? '?'}, salience ${f.salience ?? '?'}) ${f.body}`).join('\n');
  }),
);

// ── peak schedule today ──────────────────────────────────────────────────────
server.registerTool(
  'vitality_peak_today',
  {
    title: "Today's schedule (Peak)",
    description: "Today's tasks and events from the Peak planner timeline, with times and done state.",
  },
  safe(async () => {
    const v = await getDb();
    const [tasks, goal] = await Promise.all([getPeakToday(v), getVitalsGoal(v)]);
    const lines: string[] = [];
    if (goal) lines.push(`Active vitals goal: ${goal.direction} ${goal.metric}${goal.targetValue != null ? ` → ${goal.targetValue}` : ''} (confidence ${goal.confidence ?? '?'}).`, '');
    if (!tasks.length) {
      lines.push('No tasks or events scheduled for today.');
      return lines.join('\n');
    }
    for (const t of tasks) {
      const when = t.hour != null ? fmtHour(t.hour) + (t.endHour != null ? `–${fmtHour(t.endHour)}` : '') : 'anytime';
      lines.push(`  ${t.done ? '✓' : '○'} ${when} — ${t.title}${t.kind === 'event' ? ` [${t.eventType ?? 'event'}]` : ''}`);
    }
    return lines.join('\n');
  }),
);

// ── boot ──────────────────────────────────────────────────────────────────────
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('[vitality-mcp] ready (read-only). Tools registered. Waiting on stdio…');
}

main().catch((err) => {
  console.error('[vitality-mcp] fatal:', err);
  process.exit(1);
});
