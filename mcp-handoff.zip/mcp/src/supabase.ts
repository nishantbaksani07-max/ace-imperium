// Supabase access for the Vitality MCP.
//
// Two auth modes, resolved in env.ts:
//   • user    — anon key + email/password sign-in. Every query runs under the
//               user's own row-level-security context (exactly like the site).
//               The server can structurally only ever see this user's data.
//   • service — service-role key + explicit user id. Bypasses RLS, so we scope
//               EVERY query to that user id by hand. Opt-in, local-only.
//
// The client + resolved user id are cached: we authenticate once, then reuse the
// session for every tool call in the process lifetime.

import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { getEnv } from './env.js';

export interface VitalityDb {
  db: SupabaseClient;
  userId: string;
  mode: 'user' | 'service';
}

let cached: VitalityDb | null = null;
let pending: Promise<VitalityDb> | null = null;

async function connect(): Promise<VitalityDb> {
  const env = getEnv();

  if (env.authMode === 'service') {
    const db = createClient(env.supabaseUrl, env.serviceRoleKey!, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    return { db, userId: env.userId!, mode: 'service' };
  }

  // user mode
  const db = createClient(env.supabaseUrl, env.anonKey, {
    auth: { persistSession: false, autoRefreshToken: true },
  });
  const { data, error } = await db.auth.signInWithPassword({
    email: env.userEmail!,
    password: env.userPassword!,
  });
  if (error || !data.user) {
    console.error('[vitality-mcp] sign-in failed:', error?.message ?? 'no user returned');
    throw new Error(`Vitality sign-in failed: ${error?.message ?? 'unknown error'}`);
  }
  console.error(`[vitality-mcp] signed in as ${data.user.email} (RLS-scoped).`);
  return { db, userId: data.user.id, mode: 'user' };
}

/** Get the authenticated client + user id. Authenticates once, then caches. */
export function getDb(): Promise<VitalityDb> {
  if (cached) return Promise.resolve(cached);
  if (pending) return pending;
  pending = connect()
    .then((resolved) => {
      cached = resolved;
      pending = null;
      return resolved;
    })
    .catch((err) => {
      pending = null;
      throw err;
    });
  return pending;
}
