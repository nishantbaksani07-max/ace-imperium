# Vitality daily briefing — scheduled agent

This is the prompt for a **scheduled Claude agent** (a cron routine) that reads
your Vitality data through the MCP and delivers a short, human briefing. It does
not write anything — read-only, like the whole MCP.

## How it works

```
cron fires  ──▶  Claude agent  ──▶  vitality_daily_briefing (MCP tool)
                                     │
                                     └─▶ runs the nudge engine over your
                                         sleep / training / nutrition / weight /
                                         subscriptions / notes, returns a
                                         prioritized briefing
                      ▼
            agent relays it to you (chat output, or a channel you wire up)
```

Two scheduling options:

1. **Claude Code routine (recommended).** When you're back, run `/schedule` and
   create a routine on the cadence you want (e.g. 7:30am + 9:30pm). Paste the
   **agent prompt** below as the routine's task. The routine must have the
   `vitality` MCP server enabled (it's in your `.mcp.json`).
   _Left for you to create — pick the times + where the report should land
   (chat, a note, an email via the Gmail MCP). Outward delivery is your call._

2. **Plain cron, no MCP.** If you just want the text in a file/notification:
   `cd mcp && npm run briefing` prints the briefing; pipe it wherever
   (`>> ~/vitality-briefings.log`, `terminal-notifier`, etc.).

## The agent prompt (paste into /schedule)

> You are my Vitality morning/evening coach. Call the `vitality_daily_briefing`
> MCP tool. Then write me a SHORT brief (≤120 words), warm and direct, in this
> order: anything 🔴 urgent first (a trial ending, a recovery crash), then the
> single most useful 🟡 suggestion for right now, then a one-line status. Lead
> with sleep timing if it's evening, training readiness if it's morning. Use my
> first name. Never invent data the tool didn't return. If the tool reports a
> coverage gap (water/goals/etc. not visible), don't mention it unless it's
> relevant. End with one concrete next action.

## Tuning

- **Morning vs evening:** create two routines with slightly different prompts —
  morning leans on `training_readiness` + today's schedule; evening leans on
  `sleep_status` (the "go to bed at X" nudge) + tomorrow's first event.
- **Quieter briefings:** tell the agent to only message you if there's at least
  one 🔴 or 🟡 — otherwise stay silent.
- **Delivery:** the agent can drop the brief into a Vitality note (future write
  tool), email it (Gmail MCP), or just print it in the routine's run log.
