# Vitality ↔ Claude — MCP integration

**Status:** v0.1 built (local, read-only) · hosted/multi-user designed · not yet committed
**Code:** [`mcp/`](../mcp/) · **Superpowers:** yes (multi-agent data-substrate mapping)
**Date:** 2026-06-15

This doc is the full picture of what a Vitality MCP can do: the mental model, the
working v0.1, the complete capability map ("everything it can do"), the nudge
catalog, both architectures (local + hosted), and the security model. The README
in [`mcp/`](../mcp/README.md) is the quickstart; this is the design.

---

## 1. The mental model (what MCP is, honestly)

MCP (Model Context Protocol) exposes **tools** (functions Claude can call) and
**resources** (data Claude can read) to an MCP *client* — Claude Code in VSCode,
or Claude Desktop. Vitality is the **server**; Claude is the client.

Three things people conflate, separated:

| You imagine | Reality | Mechanism |
|---|---|---|
| "Vitality watches my chat" | **Claude reads Vitality** when relevant to what you asked. It's pull, on-demand. | MCP tool call |
| "It tells me when to sleep, unprompted" | Needs a **scheduler** to push. MCP is the data source; a cron'd agent is the trigger. | Scheduled agent + MCP |
| "It's pinned on my left" | UI, separate from MCP. The chat is the interface; or open the web app in a side panel. | n/a |

The flip that matters: **it's not Vitality monitoring you — it's Claude reading
your file to inform the conversation**, the same way the in-app mentor does
([lib/coach/context.ts](../lib/coach/context.ts) is the in-app version of exactly
this aggregation).

---

## 2. What's built (v0.1 — local, read-only)

A standalone Node/TypeScript stdio MCP server in [`mcp/`](../mcp/):

- **12 read tools** (table below) scoped to one user.
- **A nudge engine** ([mcp/src/nudges.ts](../mcp/src/nudges.ts)) that derives a
  prioritized **daily briefing** across every readable domain.
- **A scheduled-agent wrapper** ([mcp/agents/daily-briefing.md](../mcp/agents/daily-briefing.md))
  for morning/evening delivery.
- **RLS-respecting auth by default** (signs in as the user with the anon key);
  service-role is opt-in and flagged.
- Verified: installs, typechecks, builds, and answers the MCP `initialize` +
  `tools/list` handshake with all 12 tools.

Read-only by design — there are **no write tools** in v0.1.

---

## 3. Everything it can do — capability map

Organized by life domain. Each shows: **read** (data the MCP can surface),
**derive** (nudges/insight computed from it), and **act** (future write/action
tools — none built yet). "Source" notes whether the data is server-readable today.

### 3.1 Sleep & recovery — _"when should I sleep?"_ ✅ fully readable
- **Source:** `wearable_data` (Whoop/Oura/Fitbit: `sleep_hours`, `sleep_perf`,
  `recovery`, `hrv`, `rhr`, `strain`) + `peak_tracker_prefs` (`wake_time`,
  `sleep_need_hours`, `recovery_level`).
- **Read:** recent nights, recovery, HRV/RHR trend.
- **Derive (built):** recommended **lights-out time** = wake − sleep-need,
  shifted earlier when carrying **sleep debt** (7-day deficit) or when latest
  recovery < 50. "Recovery is low → prioritize an early night."
- **Act (future):** set tonight's bedtime reminder; write a wind-down task into
  the Peak schedule (`peak_tracker_tasks`).

### 3.2 Training readiness — _"should I train hard today?"_ ✅ readable
- **Source:** `wearable_data.recovery` + `workouts` (submitted sessions).
- **Derive (built):** recovery → **Peak / Solid / Tired / Low / Drained** tier
  (SKILL.md tiers) → push/normal/moderate/light/rest. Weekly session count;
  flags zero-session weeks.
- **Act (future):** swap today's split day to recovery; auto-deload suggestion.

### 3.3 Nutrition / fuel — _"am I on track to eat well?"_ ✅ readable
- **Source:** `nutrition_goals` + `nutrition_meals` (`totals` per `day_key`).
- **Derive (built):** today's kcal/protein vs target; protein-gap nudge; recent
  daily average. Adaptive check-in is in-app today
  ([lib/nutrition/adaptive](../lib/nutrition/adaptive.ts)) — portable later.
- **Act (future):** log a meal/template (`nutrition_meals`, `nutrition_templates`).

### 3.4 Weight — _"is my weight matching my goal?"_ ✅ readable
- **Source:** `weights` (canonical kg; display converts to the user's units).
- **Derive (built):** trend over a window; **goal-misalignment** flag (cutting
  but trending up, or bulking but trending down).
- **Act (future):** log a weigh-in.

### 3.5 Subscriptions & finance — _"what should I cancel?"_ ✅ readable (with one caveat)
- **Source:** `finance_subscriptions`, `finance_accounts`, `finance_orders`,
  `finance_net_worth_history`, `finance_prefs`. (BUILD13 moved finance to
  Supabase; [state.ts](../app/app/finance/state.ts) confirms "source of truth is
  Supabase, RLS-scoped".)
- **Read:** all subs (monthly-normalized), net worth, accounts, upcoming orders.
- **Derive (built):** total monthly/yearly burn; **trial ending** (urgent);
  **price hike** detection (`previous_amount_chf`); **renewals due this week**;
  **review candidates** = priciest subs.
- **⚠ The honest limit:** there is **no `last_used_at` / usage signal** in the
  schema, so "unused" can't be auto-detected. The MCP surfaces cost/trials/hikes
  and says so. A real "cancel what you don't use" needs a usage signal (see §8).
- **Act (future):** mark a sub for cancellation / draft a cancellation; flag a
  wishlist item as affordable when net worth crosses a threshold.

### 3.6 Notes & reminders — _"what did I tell myself to do?"_ ✅ readable
- **Source:** `notes` (the Mentor "void" + quick-jot inbox).
- **Derive (built):** surfaces recent notes that often carry time-sensitive
  intent ("event 7pm tomorrow").
- **Act (future):** create a note; promote a note to a goal/task.

### 3.7 Durable user facts — the memory layer ✅ readable
- **Source:** `user_facts` (hobbies, stressors, preferences, context, ranked by
  `salience`) + `coach_memory.summary`.
- **Read:** what Vitality "knows about you" — lets any Claude session inherit the
  in-app mentor's memory.
- **Act (future):** write a new durable fact from a Claude conversation.

### 3.8 Peak schedule & vitals goals ✅ readable
- **Source:** `peak_tracker_tasks` (today's timeline), `vitals_goals` (active
  metric goal).
- **Read:** today's events/tasks + the one active wearable-metric goal.
- **Act (future):** add/complete a task; set a vitals goal.

### 3.9 Blocked today — browser-only (`localStorage`) ⛔ not server-readable
These have **no Supabase persistence** yet, so the server cannot see them. The
briefing names them as gaps rather than pretending.

| Module | Store | To unblock |
|---|---|---|
| Water | `vitality_water_v1` | mirror to the (dormant) `water_log` table |
| Goals / streaks | `vitality_goals_v1` | add a `goals` table |
| Supplement intake | `vitality_supplements_v1` | add a `supplement_log` table |
| Brand / socials | `vitality_brand_v1` | add `brand_*` tables |
| Peak substance logs | part of `vitality_peak_v1` | add a `peak_substance_log` table |

Each is a small migration away from being a first-class MCP domain. **This is the
single highest-leverage follow-up** if the MCP matters: every localStorage module
moved to Supabase becomes instantly visible to Claude *and* syncable across
devices in the app itself.

---

## 4. Nudge catalog

The briefing engine ([nudges.ts](../mcp/src/nudges.ts)) emits prioritized nudges:
🔴 urgent · 🟡 suggest · · info.

**Built now:**
- 🟡/· **Bedtime** — recommended lights-out, shifted earlier for sleep debt / low recovery.
- 🟡 **Low recovery** — prioritize sleep tonight.
- ·/🟡 **Training read** — Peak/Solid/Tired/Low/Drained → action; zero-session-week flag.
- ·/🟡 **Nutrition** — kcal/protein status; protein-gap nudge.
- ·/🟡 **Weight** — trend; goal-misalignment.
- 🔴 **Trial ending** (≤7d) · 🟡 **price hike** · · **renewals this week** · 🟡 **review priciest subs**.
- · **Reminders** — recent notes surfaced.
- · **Coverage** — what the briefing can't see.

**Future (need either new data or write tools):**
- Hydration behind target (needs water in Supabase).
- Goal streak at risk (needs goals in Supabase).
- Supplements not taken today (needs supplement log in Supabase).
- "Net worth crossed your wishlist target" (have the data — easy add).
- Wearable-goal progress vs `vitals_goals` target.
- Caffeine-too-late vs bedtime (needs substance log in Supabase).

---

## 5. Architecture

### 5.1 Local (built) — personal, one user
```
Claude Code / Desktop ──stdio──▶ vitality-mcp (Node)
                                     │  anon key + your sign-in  (RLS as you)
                                     ▼
                                  Supabase
```
- Lowest friction, zero new infra, no OAuth.
- Auth = your email/password → RLS-scoped session. Service-role is opt-in only.
- This is what's in [`mcp/`](../mcp/).

### 5.2 Hosted (designed) — "Connect Vitality to Claude" as a product feature
A **remote MCP endpoint inside the Next.js app**, so any user can connect their
own Claude — the same standalone→hosted story as the rest of Vitality, applied to
the AI layer.

```
Anyone's Claude ──HTTP (OAuth)──▶ /app/api/mcp  ──▶ Supabase (their RLS context)
```
- **Transport:** Streamable HTTP MCP (the SDK supports it) as a route handler
  under `app/api/mcp/` — fits the "all third-party access goes through route
  handlers" rule (CLAUDE.md #4).
- **Auth:** OAuth 2.1 (MCP's auth spec) → mint a per-user token → every tool
  resolves `auth.uid()` and queries run under that user's RLS. No service role.
- **Tier gating (CLAUDE.md #5):** make the MCP a **paid-tier feature** — check
  `profiles.tier` server-side before serving tool calls, exactly like the
  existing pattern. A natural Plus/Pro perk.
- **Reuse:** the tool logic is the same; only the auth/transport layer differs.
  The query layer can converge with [lib/coach/collectors.ts](../lib/coach/collectors.ts).

### 5.3 Write tools (future, both modes)
Read-only is the safe v1. Writes (log a weigh-in, create a note, mark a sub for
cancel, add a Peak task) are a clean follow-up — each maps to an existing table
with RLS already enforcing ownership. Gate destructive/outward actions behind
explicit confirmation.

---

## 6. Security model

1. **Read-only v0.1** — no mutation surface at all.
2. **RLS-respecting by default** — user-session auth means the server is
   structurally confined to one user's data; RLS is the enforcement, not app code.
3. **Service-role is opt-in, loud, and local-only** — it bypasses RLS (CLAUDE.md
   #3), so it's gated behind an explicit env pair, warns on boot, and is
   documented as never-ship-to-client. Flagged for Luke before any hosted use.
4. **No keys to the client** — anon key is public-safe; service role/Supabase
   secrets stay in the server process (CLAUDE.md #4).
5. **Hosted = OAuth + per-user RLS + tier check** — no shared secret, no RLS
   bypass, paid-tier gated.
6. **stdout discipline** — all logs to stderr; stdout is the protocol channel.

---

## 7. Proactive delivery (the "tell me" part)

MCP is pull; proactivity needs a scheduler. Chosen path: **scheduled agent
reports**. A cron'd Claude routine calls `vitality_daily_briefing` and relays a
short brief (morning: readiness + schedule; evening: bedtime + tomorrow's first
event). Prompt + wiring in [mcp/agents/daily-briefing.md](../mcp/agents/daily-briefing.md).
Creating the actual routine (times + delivery channel) is left to Luke — outward
delivery and cadence are a human call.

Plain-cron fallback (no MCP): `npm run briefing` prints the brief; pipe it to a
file or `terminal-notifier`.

---

## 8. Honest limits

- **No subscription usage signal** → can't auto-detect "unused" subs. Surfaces
  cost/trials/hikes instead. A real version needs a usage signal (manual
  last-used tap, or per-service API — most have none).
- **Browser-only modules invisible** (water, goals, supplements, brand) until
  migrated to Supabase. The briefing says so.
- **No real cancellation API** — most services can't be cancelled programmatically;
  the realistic action is *flag + draft*, you click send.
- **FX** — finance amounts are canonical CHF; converting to the display currency
  needs the app's FX route (not wired into the MCP yet).
- **Vitality composite score** — the MCP uses recovery tiers directly rather than
  re-implementing the full [lib/vitality](../lib/vitality/) contributor engine.

---

## 9. Roadmap

1. **Now:** v0.1 local read-only MCP + daily briefing (done).
2. **Wire the schedule:** create the morning/evening routine via `/schedule`.
3. **Unblock localStorage modules:** migrate water → `water_log`, add `goals`,
   `supplement_log` tables. Biggest coverage win; also helps the app.
4. **Add write tools:** weigh-in, note, Peak task, mark-sub-for-cancel (confirmed).
5. **Hosted MCP:** `app/api/mcp/` Streamable-HTTP endpoint, OAuth, tier-gated —
   ship "Connect Vitality to Claude" as a Plus/Pro feature.
6. **Subscription usage signal:** a lightweight "still using this?" tap so the
   "cancel what you don't use" nudge becomes real.
